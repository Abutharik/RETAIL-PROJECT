-- SQL queries for retail profit analysis
SELECT Category, Sub_Category, SUM(Sales), SUM(Profit), SUM(Profit)/SUM(Sales) AS Profit_Margin FROM Superstore GROUP BY Category, Sub_Category;
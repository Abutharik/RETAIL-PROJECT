# Retail Business Performance Analysis

This project analyzes sales and profitability trends using SQL, Python, and Tableau.